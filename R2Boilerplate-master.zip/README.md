# RoR2 x10 Mod

Originally made by megidont, however it wasn't working and the source code wasn't available so by using dotPeek I decompiled the mod to update it.

Megidont, if you see this and want me to remove it, let me know

## Changelog

**1.0.0**

* Release of my first mod.
