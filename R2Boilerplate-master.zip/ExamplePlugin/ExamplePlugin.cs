// Decompiled with JetBrains decompiler
// Type: megidont.X10
// Assembly: 10X Pickup Mod, Version=4.2.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F3C76EB-9047-40EB-96FB-BAB88819A5F3
// Assembly location: C:\Users\gudak\Desktop\x10.dll

using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using RoR2;
using System;
using System.Collections.Generic;
using System.Linq;

namespace megidont
{
    [BepInDependency("com.bepis.r2api", BepInDependency.DependencyFlags.HardDependency)]
    [BepInPlugin("gudako.X10", "10x Pickup Mod", "1.0.0")]
    [HarmonyPatch]
    public class X10 : BaseUnityPlugin
    {
        internal static ManualLogSource log;
        public static ConfigFile config;
        public static ConfigEntry<int> multiplier;
        public static ConfigEntry<string> forbiddenItems;
        public static ConfigEntry<bool> fixVoidItems;
        public static ConfigEntry<bool> enableIndex109;
        public static ConfigEntry<bool> enableIndex167;
        public static ConfigEntry<bool> enableIndex168;
        public static ConfigEntry<bool> enableIndex176;
        public static string defaultForbiddenItems = "ITEM_ADAPTIVEARMOR_NAME,ITEM_BOOSTATTACKSPEED_NAME,ITEM_BOOSTDAMAGE_NAME,ITEM_BOOSTEQUIPMENTRECHARGE_NAME,ITEM_BOOSTHP_NAME,ITEM_CRIPPLEWARDONLEVEL_NAME,ITEM_CUTHP_NAME,ITEM_DRIZZLEPLAYERHELPER_NAME,ITEM_EXTRALIFECONSUMED_NAME,ITEM_GHOST_NAME,ITEM_HEALTHDECAY_NAME,ITEM_INVADINGDOPPELGANGER_NAME,ITEM_LEVELBONUS_NAME,ITEM_MINIONLEASH_NAME,ITEM_MONSOONPLAYERHELPER_NAME,ITEM_SCRAPGREEN_NAME,ITEM_SCRAPRED_NAME,ITEM_SCRAPWHITE_NAME,ITEM_SCRAPYELLOW_NAME,ITEM_SKULLCOUNTER_NAME";

        public void Awake()
        {
            Harmony.CreateAndPatchAll(typeof(X10), nameof(X10));
            //X10.log = Logger.CreateLogSource("x10-3");
            this.InitConfig(X10.config);
        }

        internal void InitConfig(ConfigFile cfg)
        {
            X10.config = cfg;
            X10.multiplier = this.Config.Bind<int>("BasicConfig", "Multiplier", 10, "Change this number to change pickup quantity.");
            X10.forbiddenItems = this.Config.Bind<string>("BasicConfig", "Forbidden Item List", X10.defaultForbiddenItems, "Change this list to change which items aren't multiplied. By default, this contains internally used enemy items. You can find a list of internal item names at https://github.com/risk-of-thunder/R2Wiki/wiki/Item-&-Equipment-IDs-and-Names - from there it should be fairly easy to figure out the rest!");
            X10.fixVoidItems = this.Config.Bind<bool>("BasicConfig", "Enable Void Item Fix", true, "During testing, the multiplier for void items ended up squaring the drop. Oops. Reenable if you want.");
            X10.enableIndex109 = this.Config.Bind<bool>("EnableByIndex", "Enable multiplication of MinHealthPercentage", false, "Because these items do not have nameTokens, we have options here in case you wanna enable them.");
            X10.enableIndex167 = this.Config.Bind<bool>("EnableByIndex", "Enable multiplication of TeamSizeDamageBonus", false, "Because these items do not have nameTokens, we have options here in case you wanna enable them.");
            X10.enableIndex168 = this.Config.Bind<bool>("EnableByIndex", "Enable multiplication of TeleportWhenOob", false, "Because these items do not have nameTokens, we have options here in case you wanna enable them.");
            X10.enableIndex176 = this.Config.Bind<bool>("EnableByIndex", "Enable multiplication of UseAmbientLevel", false, "Because these items do not have nameTokens, we have options here in case you wanna enable them.");
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(ItemCatalog), "Init")]
        public static void Initialize()
        {
            string str = RoR2Content.Items.AdaptiveArmor.nameToken + "," + RoR2Content.Items.BoostAttackSpeed.nameToken + "," + RoR2Content.Items.BoostDamage.nameToken + "," + RoR2Content.Items.BoostEquipmentRecharge.nameToken + "," + RoR2Content.Items.BoostHp.nameToken + "," + RoR2Content.Items.CrippleWardOnLevel.nameToken + "," + RoR2Content.Items.CutHp.nameToken + "," + RoR2Content.Items.DrizzlePlayerHelper.nameToken + "," + RoR2Content.Items.ExtraLifeConsumed.nameToken + "," + RoR2Content.Items.Ghost.nameToken + "," + RoR2Content.Items.HealthDecay.nameToken + "," + RoR2Content.Items.InvadingDoppelganger.nameToken + "," + RoR2Content.Items.LevelBonus.nameToken + "," + RoR2Content.Items.MinionLeash.nameToken + "," + RoR2Content.Items.MonsoonPlayerHelper.nameToken + "," + RoR2Content.Items.ScrapGreen.nameToken + "," + RoR2Content.Items.ScrapRed.nameToken + "," + RoR2Content.Items.ScrapWhite.nameToken + "," + RoR2Content.Items.ScrapYellow.nameToken + "," + JunkContent.Items.SkullCounter.nameToken;
            if (!(X10.defaultForbiddenItems != str))
                return;
            X10.log.LogFatal((object)("Critical Error:\nThe current default forbidden item list is NOT CORRECT.\n(this is not the one in your config, this should only happen if something goes horribly wrong.)\nThe current default set is " + X10.defaultForbiddenItems + "\nCurrent nametokens mean it should be " + str + "\nIf you know what this means, you're probably ok. If this is the only mod you are running, message me @Megidon't#0413 on discord."));
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(Inventory), "GiveItem", new Type[] { typeof(ItemIndex), typeof(int) })]
        public static void multiplyItems(ItemIndex itemIndex, ref int count)
        {
            ItemDef itemDef = ItemCatalog.GetItemDef(itemIndex);
            int[] source1 = new int[4];
            if (!X10.enableIndex109.Value)
                source1[0] = 109;
            if (!X10.enableIndex167.Value)
                source1[0] = 167;
            if (!X10.enableIndex168.Value)
                source1[0] = 168;
            if (!X10.enableIndex176.Value)
                source1[0] = 176;
            ItemTier[] source2 = new ItemTier[4]
            {
        ItemTier.VoidTier1,
        ItemTier.VoidTier2,
        ItemTier.VoidTier3,
        ItemTier.VoidBoss
            };
            bool flag1 = ((IEnumerable<int>)source1).Contains<int>((int)itemIndex);
            bool flag2 = ((IEnumerable<ItemTier>)source2).Contains<ItemTier>(itemDef.tier) && X10.fixVoidItems.Value;
            if (X10.forbiddenItems.Value.Contains(itemDef.nameToken) || flag1 || flag2)
                return;
            count *= X10.multiplier.Value;
        }
    }
}
