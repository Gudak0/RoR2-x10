# 10x Pickup Mod

~~This mod says it all; any time anyone has an item added to their inventory, player or monster, that item is added 10 times. This was made for my sister to have fun with, and I thought other people might have a laugh too! There is an additional version for 100x pickups, and when put together they do work for 1000x pickups.~~

The name of the mod is now a bit of a misnomer - By default, this mod multiplies any item pickup by 10, but that is now configurable, along with a configurable list of excluded items by their internal item name tokens (which by default includes scrap and internal use items)!